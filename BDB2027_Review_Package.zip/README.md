# Review of the first Big Data Bowl experiment

Start with `BDB2027_Cursor_Repair_Prompt.md`. It contains the audit findings and an executable brief for Cursor to repair the existing repository.

`writeup/draft.md` is an editorial revision, approximately 1,640 whitespace-delimited words including its captions and review note. Its three figure references resolve within this package. The source and measurement checks in the review remain necessary before submission.

The primary numerical results were independently recalculated from the supplied prediction CSV. No model was retrained, no tracking feature was changed, and no new football relationship was selected. The original evidence ZIP is unchanged.

## Contents

- `writeup/draft.md`: revised working draft with embedded figure paths.
- `outputs/figures/`: two original figures and a new cohort/error comparison generated from the exported predictions and original interval.
- `review/verification.json` and `review/verified_metrics.csv`: independent numerical checks.
- `review/recompute_predictions.py`: source for those checks and the new comparison figure.
- `BDB2027_Cursor_Repair_Prompt.md`: the concrete next implementation brief.

## Reproduce this review's numerical checks

With NumPy, pandas, and Matplotlib installed, run from the package root:

```bash
python review/recompute_predictions.py --evidence /path/to/extracted/original/bdb2027_evidence --output .
```

This requires the original evidence's `outputs/predictions.csv`, `outputs/metrics.json`, and `reports/freeze_manifest.json`. It audits predictions already made; it is not a replacement for the full research pipeline or the required public Kaggle Notebook.
