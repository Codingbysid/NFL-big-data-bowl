# Big Data Bowl 2027 — evidence review and next Cursor prompt

## Assessment

The exported prediction results are internally consistent. I independently reconstructed all nine primary model/cohort player-mean errors and their route-level errors from `outputs/predictions.csv`. The primary comparison is −0.0158076339661484 yards; the CSV has 19 evaluation players, 3,552 evaluation routes, and no duplicated player-play keys. The final manifest's 49 training IDs do not overlap those 19 evaluation IDs. A separate 20,000-resample paired-player check produced approximately [−0.0323, +0.0016], consistent with the submitted [−0.0333, +0.0022]. This numerical check does not validate the upstream feature extraction or model fitting.

The current experiment has not established the proposed positive relationship. It also does not establish that every cut metric is useless. Its main competitive weakness is the limited demonstrated football application. A negative result can be valuable, but the reproducibility and measurement claims need repair before the writeup can carry that result credibly.

### Findings that change the next step

| Priority | Finding | Evidence and required correction |
|---|---|---|
| High | The supplied notebook cannot reproduce the study from this ZIP. | It imports an absent `bdb2027` package and reads absent `data/interim/...` JSON/Parquet files. It displays precomputed figures and runs a synthetic turn; it does not run extraction/modeling from raw inputs. Include the complete package/config and a clean end-to-end notebook. |
| High | The 0.3-yard practice rule is unsupported. | The reported 0.276-yard within-player SD is across drills/attempts. It is not established same-drill measurement error, and one SD is not a detectable-change threshold. Remove the rule. |
| High | Prediction differences are not solely the trait's contribution. | Final manifest: M1 ridge penalty 1.0; M2 penalty 0.3. Every shared coefficient can change. The fitted-model comparison is legitimate if tuning was valid, but the Noel/Lane attribution is too strong. Add a transparent decomposition and a common-penalty diagnostic. |
| High | Visual validation is incomplete. | The review sheet has 64 trajectories but only 8 individual verdicts: 4 Combine and 4 NFL. The other 56 say contact-sheet/montage only. It does not establish detector precision/recall or complete the requested individual review. |
| High | The original evaluated state must be preserved. | The report suggests repeating `freeze` after a plotting-only change. Preserve the original manifest/results and source snapshot; separate scientific code fingerprints from presentation fingerprints. A fresh freeze cannot make the already-viewed 2025 outcomes unseen again. |
| Medium | The writeup overstates conventional testing. | M1−M0 player-mean error: −0.00598 in 2023, −0.00024 in 2024, −0.03937 in 2025. On individual 2025 routes, M0 has lower MAE than either Combine model. Limit the conclusion to the actual comparison. |
| Medium | Reliability is mislabeled as repeatability. | Most drill types occur once. The reported ICC is cross-drill consistency. Its player-mean SD also differs from a latent between-player SD. Export the estimator and component calculations; do not report cross-drill dispersion as sensor noise. |
| Medium | The movement and separation analyses use different populations. | Prediction includes GO/HITCH/CROSS/etc. while only about 10–11% of tracked forward passes have a kept NFL cut. Make this distinction explicit; a cut-specific diagnostic would be exploratory now. |
| Medium | Several central claims cannot be independently reproduced from the package. | There is no attempt-level cut table, NFL trait table, final model object, full config, source code, or tests. Most claim-ledger source paths point to omitted files. The package contains holdout Combine traits but not the development traits. |
| Medium | Figures are referenced but not embedded in the draft. | The attached Markdown has zero image references, despite discussing six figures. Figure 2 uses the 2023 support counts, which need a year label; its binary mask does not need a continuous color scale. Figure 5 error bars need a precise definition. |

The reviewed draft corrects the wording, adds real image links, removes the practice threshold, and shows all three cohort results together. It preserves the original model results. It remains a working draft pending the checks below.

## Paste the following brief into Cursor Agent

Continue the existing Big Data Bowl repository. The first experiment is complete and the 2025 outcomes have been viewed. Repair reproducibility, audit the measurements and attribution, and improve the writeup using the existing evidence. Implement and run the authorized work below. Retain the original negative/inconclusive experiment and all its artifacts.

### 1. Preserve the evaluated experiment

Archive the original protocol, experiment log, freeze manifest, predictions, metric files, fitted transforms/models, and scientific source snapshot. The supplied original manifest has:

```text
frozen_at: 2026-10-08T08:54:45Z
config_hash: dfc5bbb37f447ee85ca1eea3d26d2c0e7a746567c39394c2f78be23be0fb3505
code_hash: a61da719cfad7712dc182e84bdd3d345479615745b40e344c4f635787e5dbdaf
data_version: f57bbd690bd2b5d3
training players: 49
training routes: 10,603
evaluation players: 19
evaluation routes: 3,552
```

Recover the evaluated source state from git/history if available. If it cannot be recovered, state that explicitly. Do not overwrite the historical manifest or generate a new one and call it the original freeze. Separate reproducibility runs, presentation-only changes, confirmed scientific bug fixes, and new exploratory analyses in the log.

Add a scientific fingerprint covering extraction, feature construction, transformations, modeling, config, training membership, and data; track plotting/text fingerprints separately. A plotting edit must not require refitting a model. Verify prediction equality when classifying a change as presentation-only.

The original 2025 result remains the original evaluation. Reproducing it from the original frozen recipe is allowed. New scientific decisions informed by this review are post-evaluation and must be labeled accordingly. No repeated search for a favorable 2025 result.

### 2. Make the code genuinely portable

The handoff ZIP lacks `src/bdb2027`, `pyproject.toml`, `config/research.yaml`, tests, fitted models, and many files read by the notebook. Supply the full code and exact configuration, including all random seeds and dependencies. Include a source revision/fingerprint, actual test output, and a machine-readable mapping from each published claim to a packaged artifact or a deterministic command that generates it.

Replace the display-only notebook with a clean-kernel workflow that:

1. Locates the nine competition CSVs from a configurable root/Kaggle mount.
2. Loads included source code or contains the necessary implementation.
3. Runs audit, extraction, the recorded development procedure, original-recipe fitting/reproduction, evaluation, and figure generation with explicit caches.
4. Produces the reported results without undocumented local intermediate files.
5. Documents which outputs are an exact reproduction and which are later diagnostics.

Support a CPU-only clean run. Preserve streaming and cache invalidation. Execute from a fresh output directory so missing dependencies cannot be hidden by previous artifacts. Test the package/ZIP in an isolated environment with no editable installation from the source repository.

Run on Kaggle only if the environment is actually available. Otherwise report the verified local run and the exact remaining Kaggle step. Do not claim Kaggle success or public-notebook completeness until verified; prepare files but do not publish or submit automatically.

### 3. Export the evidence needed to inspect the measurement

Create compact attempt/cut tables for every cohort with:

- Player, year, attempt/event key, drill/route family, and model fold where relevant.
- Raw and smoothed timestamps/coordinates for the reviewed trajectory windows, or a deterministic raw-row lookup.
- Cut reference time, incoming and outgoing heading windows, entry speed, net angle, raw half-second exit distance, expected exit distance, residual, and support cell.
- Every eligibility flag and exclusion reason, event boundaries, gap/interpolation flags, and smoothing setting.
- Demand-model fit membership, transform/fold ID, and whether residuals are out-of-fold or from a final fit.

Export development and holdout player traits, corresponding NFL traits, attempt counts, uncertainty diagnostics, profile marginal predictions, and the exact rows used in translation correlations. Reproduce the stated correlations, reliability estimates, and coefficient from these artifacts.

Resolve these questions with source code and numbers:

- Do residual construction, imputation, scaling, support-cell selection, and penalty tuning stay inside the appropriate training folds? A global demand fit must not leak into player-held-out validation.
- How are several cut candidates within one attempt handled? Are attempts equally weighted?
- Does the primary Combine trait include only common-support cuts, and how do its counts relate to the 406-cut/69-player feasibility count? Identify every population explicitly.
- Does the demand model leave substantial systematic residuals by drill family, entry speed, or angle? Inspect calibration rather than assuming the covariates have been fully removed because they appear in a ridge formula.
- Are detectors finding the intended break rather than a release arc, a later bend, or the wrong part of a double move? Verify stable headings, circular-angle handling, actual time units, and pass/contact window boundaries.
- Explain the 2023 support plot versus the final 2023–24 support table; label both training sets correctly.

### 4. Complete movement-quality review

The existing sheet contains 34 Combine and 30 NFL examples, but 56 are only marked `montage`. Complete individual review on a deterministic stratified development sample of at least 30 Combine attempts and 30 NFL routes, including kept and rejected cases. Hide names, draft slot, and separation during the review. Preserve the earlier notes and timestamp the new review as post-evaluation.

For each record, assess whether a relevant turn exists, whether the detector selects the intended turn, whether its heading windows and reference time are defensible, and whether all timing restrictions are satisfied. Record indeterminate cases honestly. Estimate precision/recall only if the sampling design and labels support those quantities; otherwise report stratified agreement/error counts and their denominators.

If new review exposes a scientific defect, record the defect, fix, and scope. Preserve original predictions and report corrected results as a correction. Do not relabel a detector revision made after viewing 2025 as prespecified. A corrected study can be useful without pretending to have a fresh holdout.

### 5. Correct reliability and remove the practice threshold

Explain the exact ICC formula, weighting, variance components, fold treatment, and bootstrap unit. The reported values are:

```text
ICC: 0.1776034897
within-receiver residual SD: 0.2757477114 yards
SD of receiver mean residuals: 0.1841850713 yards
harmonic attempt count: 4.3620970368
```

The raw SD of receiver means includes estimation error. It is not automatically the latent between-receiver SD used in an ICC. Reconcile those quantities without calling a mere difference in definitions a bug. Label this cross-drill consistency if drills were mostly observed once.

Audit repeated identical drill families, direction, and demand conditions. If there are enough genuinely comparable repeats, estimate same-condition repeatability separately and show counts/uncertainty. If there are not, say repeatability and a reliable-change threshold cannot be estimated from these data.

Delete the statement that changes below 0.3 yards should be treated as noise. Do not replace it with another unvalidated cutoff. For context only, if a same-condition within-person measurement SD were known and independent equal-variance errors were justified, a 95% single-measurement difference threshold would involve `1.96 * sqrt(2) * SD`, not `SD`. The current cross-drill SD does not justify applying that formula as a coaching rule.

Leave-one-attempt-out spread is a sensitivity measure; label it explicitly rather than presenting it as a confidence interval. Quantify the reliability of the actual aggregated player trait separately if the data and estimator allow it.

### 6. Separate model comparison from trait attribution

Keep the original tuned M1-versus-M2 comparison as reported. It is valid to compare independently tuned pipelines when their tuning uses only training data. Its gain does not isolate one coefficient's contribution.

Add a documented post-evaluation diagnostic using the same ridge penalty and identical preprocessing for M1 and M2. Choose the common penalty with 2023–24 grouped/nested development only; do not select it by the 2025 result. Report both improvements and failures, and retain the original comparison as the primary historical result.

For the named examples, decompose the prediction difference into the direct trait term, changes in shared coefficients, and the intercept, on a common interpretable feature basis. If the transformations differ, first express the linear predictors on that shared basis. Verify that the components sum to the total difference. A within-M2 contrast that changes only the trait is another clearly labeled model diagnostic, not a causal treatment effect.

Remove the assertion that Lane agrees with tracking only because a poor exit is rewarded unless the decomposition supports that exact statement. Keep Noel/Lane as the original rule-selected examples and Thornton as the post-hoc failure. Preserve the candidate-selection population, including any dependence on future NFL route availability; do not call a sample selected with future participation an unconditional pre-draft screen.

Show M0, M1, and M2 across all three classes, both player-mean and route-level error. Limit the conclusion about conventional testing: M1 was substantially better than M0 on 2025 player means, almost tied in 2024, and worse than M0 on 2025 route-level error and the man-coverage subset.

### 7. At most two focused exploratory diagnostics

After the repairs, investigate why this particular trait did not translate. These are development analyses motivated by the first result, not untouched confirmatory tests:

**A. Drill dependence.** On the 2023–24 development pool, inspect whether residual rank is consistent across sufficiently represented drill families. Use leave-one-drill-family-out aggregation and player-level uncertainty. Determine whether pooling heterogeneous drills masks different movements. Avoid fitting separate complex player surfaces or choosing the family with the smallest p-value.

**B. Endpoint alignment.** On the same development pool, contrast the existing all-eligible-route endpoint with a narrowly defined endpoint on validated NFL cut-bearing routes in common support. Report the cohort and coverage loss, route/coverage/context differences, and uncertainty. Use player grouping and game clustering where relevant. Do not classify unmeasured cuts as zero ability.

Predeclare the exact two analyses in a dated post-evaluation addendum before running them. Do not introduce a new position group, a feature sweep, or a large model tournament. The objective is a defensible explanation of the measurement's limitations or a bounded candidate for future validation. Keep 2025 outcomes out of selecting the revised metric. If a revised metric is shown on 2025, label that result retrospective because the class has already informed the project.

A possible football contribution is a practical process for deciding whether a Combine movement measurement is sufficiently consistent, relevant to actual NFL demands, and incrementally informative to deserve a scouting grade. Only use that framing if the repaired analysis supports each part. The original residual can remain a worked example that did not pass those checks. Do not invent a numeric composite score or guaranteed decision threshold to make the result sound actionable.

### 8. Finish the writeup and figures from the evidence

Use the reviewed draft as an editorial starting point. Retain the original primary results and incorporate confirmed corrections. Do not state that all cut metrics fail or that conventional testing is universally validated. Say that this experiment did not establish the proposed positive relationship and did not justify ranking players by this residual.

Specific fixes:

- Explain conditional evaluation on actual route contexts versus common-context prospect projections.
- Explain that the NFL movement subset differs from the performance-model route set.
- Replace “a late throw leaves no legal window” with the actual temporal condition: a throw before the required post-cut window ends makes that cut unavailable.
- Use “recorded protocol” or “prespecified in the supplied project log” unless public preregistration exists.
- Preserve the analyst-chosen 0.10-yard MAE threshold, with its actual meaning. Do not change it after observing 2025 or treat it as a universally accepted football threshold.
- Embed every included figure with valid Markdown paths. Use at most six figures and one table, with captions and total visible text comfortably below 2,000 words.
- Show uncertainty directly on the primary comparison, and label the cohort in the support chart. Use a discrete legend for a binary support mask.
- Define error bars and denominators. Do not imply precision from the number of frames or routes when inference is about players.

Produce a claim ledger whose sources all exist in the handoff or are generated by a documented command. Include unresolved limitations. Do not leave claims about training improvement, causal effects, measurement thresholds, or guaranteed undervaluation in the paper.

### 9. Required handoff

Return `bdb2027_reviewed_evidence.zip` with full source/config/tests, a genuinely executable notebook, immutable original experiment records, separately labeled correction/exploration outputs, compact per-attempt and per-player evidence, predictions, metrics, final figures, claim ledger, and updated draft. Exclude raw competition data and unnecessary caches.

Also return a short status table: numerical reproduction, pipeline reproduction, measurement review, reliability definition, attribution diagnostic, notebook execution, and Kaggle execution. Distinguish passed, failed, and not yet run. Include exact commands and the checks actually performed. Complete every feasible repair without routine confirmation requests; identify exact missing inputs if a check cannot run.

## Statistical references used in this review

- Bland and Altman, *Measurement error*, BMJ 1996;312:1654: https://www.bmj.com/content/312/7047/1654 — supports the distinction between a within-person SD and the repeatability coefficient under the requisite assumptions.
- scikit-learn, nested versus non-nested cross-validation: https://scikit-learn.org/stable/auto_examples/model_selection/plot_nested_cross_validation_iris.html — supports separating hyperparameter selection from performance evaluation.

These references support methodological corrections. They do not establish any football effect in this dataset.
