"""Audit exported predictions and plot them; this does not refit any model.

Usage: python review/recompute_predictions.py --evidence /path/to/evidence --output .
Requires numpy, pandas, matplotlib. The original evidence directory must contain
outputs/predictions.csv, outputs/metrics.json, and reports/freeze_manifest.json.
"""
from pathlib import Path
import argparse
import json

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--evidence", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    pred = pd.read_csv(args.evidence / "outputs/predictions.csv")
    metrics = json.loads((args.evidence / "outputs/metrics.json").read_text())
    manifest = json.loads((args.evidence / "reports/freeze_manifest.json").read_text())
    if pred.duplicated(["nfl_id", "game_id", "play_id"]).any():
        raise ValueError("Duplicate player-play keys")
    columns = ["y", "pred_M0", "pred_M1", "pred_M2"]
    if pred[columns].isna().any().any():
        raise ValueError("Missing primary outcomes/predictions")
    splits = ["oof_2023", "chrono_2024", "holdout_2025"]
    rows = []
    for split in splits:
        data = pred[pred.split.eq(split)]
        means = data.groupby("nfl_id")[columns].mean()
        reported = (metrics["holdout"]["primary"] if split == "holdout_2025"
                    else metrics["development"][split])
        for model in ["M0", "M1", "M2"]:
            mae = float((means.y - means[f"pred_{model}"]).abs().mean())
            route_mae = float((data.y - data[f"pred_{model}"]).abs().mean())
            if not np.isclose(mae, reported[model]["mae"], atol=1e-12, rtol=0):
                raise ValueError(f"Player MAE mismatch: {split} {model}")
            if not np.isclose(route_mae, reported[model]["route_mae"], atol=1e-12, rtol=0):
                raise ValueError(f"Route MAE mismatch: {split} {model}")
            rows.append(dict(split=split, model=model, n_players=len(means),
                             n_routes=len(data), player_mae=mae, route_mae=route_mae))
    holdout = pred[pred.split.eq("holdout_2025")]
    overlap = set(holdout.nfl_id) & set(manifest["train_ids"])
    if overlap:
        raise ValueError(f"Train/evaluation player overlap: {overlap}")
    means = holdout.groupby("nfl_id")[columns].mean()
    differences = ((means.y - means.pred_M2).abs() -
                   (means.y - means.pred_M1).abs()).to_numpy()
    rng = np.random.default_rng(2718)
    boot = differences[rng.integers(0, len(differences), (20000, len(differences)))].mean(axis=1)
    review = {
        "scope": "Independent check of exported predictions; no model retraining or raw-tracking audit",
        "primary_metrics": rows,
        "duplicated_player_play_keys": 0,
        "train_evaluation_player_overlap": 0,
        "delta_m2_minus_m1": float(differences.mean()),
        "original_reported_bootstrap": metrics["holdout"]["paired_bootstrap"],
        "independent_bootstrap_check": {
            "seed": 2718, "resamples": 20000,
            "interval": np.quantile(boot, [.025, .975]).tolist(),
            "label": "Paired players; conditional on exported fixed predictions"
        },
        "players_m2_closer": int((differences < 0).sum()),
        "players_m1_closer": int((differences > 0).sum()),
        "leave_one_player_out_delta_range": [
            float(np.min((differences.sum() - differences) / (len(differences) - 1))),
            float(np.max((differences.sum() - differences) / (len(differences) - 1)))
        ]
    }
    review_dir = args.output / "review"
    fig_dir = args.output / "outputs/figures"
    review_dir.mkdir(parents=True, exist_ok=True)
    fig_dir.mkdir(parents=True, exist_ok=True)
    (review_dir / "verification.json").write_text(json.dumps(review, indent=2) + "\n")
    frame = pd.DataFrame(rows)
    frame.to_csv(review_dir / "verified_metrics.csv", index=False)

    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 11,
                         "axes.spines.top": False, "axes.spines.right": False})
    fig, (left, right) = plt.subplots(1, 2, figsize=(11.8, 4.9),
                                     gridspec_kw={"width_ratios": [1.1, 1]})
    models = [("M0", "Context", "#6B7280"),
              ("M1", "+ Conventional", "#0072B2"),
              ("M2", "+ Tracking", "#009E73")]
    x = np.arange(3)
    for model, label, color in models:
        values = [float(frame.loc[(frame.split == split) & (frame.model == model), "player_mae"].iloc[0])
                  for split in splits]
        left.plot(x, values, marker="o", linewidth=2, markersize=7, color=color, label=label)
    left.set_xticks(x, ["2023\nOut of fold\nn = 28", "2024\nDevelopment check\nn = 21",
                        "2025\nEvaluation\nn = 19"])
    left.set_xlim(-.15, 2.15)
    left.set_ylim(.10, .26)
    left.set_ylabel("Player-mean absolute error (yards)")
    left.set_title("The tracking advantage varies by cohort", loc="left", fontsize=12, pad=18)
    left.grid(axis="y", alpha=.18)
    left.legend(loc="upper center", bbox_to_anchor=(.5, 1.01), ncol=1, frameon=False, fontsize=9)
    ci = metrics["holdout"]["paired_bootstrap"]
    delta = float(differences.mean())
    right.errorbar(delta, 0, xerr=[[delta - ci["p2_5"]], [ci["p97_5"] - delta]],
                   fmt="o", color="#009E73", capsize=7, markersize=9, elinewidth=3)
    right.axvline(0, color="#4B5563", linewidth=1)
    right.axvline(-.10, color="#9CA3AF", linestyle="--", linewidth=1)
    text_box = {"facecolor": "white", "edgecolor": "none", "pad": 2}
    right.text(-.10, -.44, "Project target\n−0.100 yards", ha="center", va="top", fontsize=9, color="#4B5563", bbox=text_box)
    right.text(delta, .20, "−0.0158 yards", ha="center", va="bottom", fontsize=12, fontweight="bold", bbox=text_box)
    right.text(delta, -.17, "95% interval\n−0.0333 to +0.0022", ha="center", va="top", fontsize=10, bbox=text_box)
    right.set_xlim(-.114, .024)
    right.set_ylim(-.85, .65)
    right.set_yticks([])
    right.set_xticks([-.10, -.05, 0], ["−0.10", "−0.05", "0.00"])
    right.set_xlabel("Tracking − conventional error (yards)\nNegative values favor tracking")
    right.set_title("The 2025 interval includes no improvement", loc="left", fontsize=12, pad=18)
    right.spines["left"].set_visible(False)
    fig.text(.07, .02, "Source: exported prediction CSV; interval from original metrics.json. "
             "Bootstrap conditions on fitted models.", fontsize=9, color="#4B5563")
    fig.subplots_adjust(left=.07, right=.98, bottom=.24, top=.88, wspace=.32)
    for extension in ["png", "pdf"]:
        fig.savefig(fig_dir / f"model_comparison_reviewed.{extension}", dpi=200, facecolor="white")
    plt.close(fig)
    print(json.dumps({"metrics_match": True, "delta": delta,
                      "independent_interval": review["independent_bootstrap_check"]["interval"]}))


if __name__ == "__main__":
    main()
