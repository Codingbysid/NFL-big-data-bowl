# The Cost of a Cut

Two wide receivers run nearly the same forty. A scout still has to decide whether anything else at the Combine is worth a second look, and a coach wants a drill number that is not pretending to be a season grade. The number tested here is yards gained along the outgoing direction in the half-second after a turn, once entry speed and turn angle are accounted for. The hope was that the receiver who gets out of the cut cleanly would separate more as a rookie. That was a hypothesis. The 2025 class did not support it.

The measurement is a cut-exit residual, in yards: yards gained along the exit, minus the yards expected for that entry speed, angle, and drill. The pre-registered guess was that a larger residual would line up with more rookie separation. The model fit on the 2023 and 2024 receivers went the other way, and the 2025 check did not rescue the guess.

## Who could be studied

The player file has 106 wide receivers: 38 from 2023, 31 from 2024, and 37 from 2025. Tight ends stay out. A wide receiver who lines up in the slot stays in.

An eligible route is a regular-season play in the player's draft year, with a forward pass, a route other than a screen, and a recorded separation. Separation is present on completions, incompletions, and interceptions, including untargeted routes. It is absent on sacks and scrambles, and those plays are left out. A missing separation is never stored as zero. Preseason, postseason, and later seasons of the earlier classes are out. The schedule file has 816 regular-season games, 147 preseason games, and 39 postseason games, so the regular-season filter is explicit.

Table 1. Eligible routes are rookie regular-season plays with a forward pass and a separation label. The model keeps receivers with at least 20 of those routes.

| Class | Roster | Eligible routes | Players with any | Modeled players | Modeled routes |
| --- | --- | --- | --- | --- | --- |
| 2023 | 38 | 6,280 | 29 | 28 | 6,279 |
| 2024 | 31 | 4,368 | 27 | 21 | 4,324 |
| 2025 | 37 | 3,605 | 23 | 19 | 3,552 |

One 2024 receiver never appears in the play file. Of the 18 receivers in the 2025 class below the 20-route bar, 13 were undrafted, against 1 of the 19 who were modeled. The study describes receivers who played a real rookie sample.

Game tracking follows the prospect. Most plays contain one to a few tracked players, not a defense. Separation is the competition's label. It is not rebuilt from defenders who are absent.

## A half-second after the turn

Figure 1 shows a combine speed-out with the name withheld. The receiver accelerates, bends, and holds his speed. The mark is the halfway point of the heading change, not the slowest frame. The arrow is the next half-second along the direction he is leaving in. That length is the raw exit distance. On the 2023–24 cuts in the trait, a speed-out covers a median 2.92 yards and a dagger 3.28. Those lengths become a trait only after the demand of the rep is removed.

Expected exit is a ridge fit on training receivers only: entry speed, turn size, their product, and a shrunk drill offset. Each training receiver counts equally, and each attempt counts equally inside that. The trait is the median residual. Fewer than two attempts leaves it blank. Most drills are run once, so reliability is across drills, not two reps of the same drill. Comebacks and gauntlet work stay out. An outcome-blind look at the paths also set the entry-speed floor at 4 yards per second, because slower marks were release arcs and low-speed wiggles.

Figure 2 is where Combine cuts and NFL cuts overlap: about 6 to 8 yards per second into a turn of 30 to 90 degrees. Cell counts are Combine over NFL. Outside that band the translation claim is not made. Held-out 2023 attempt residuals have a reliability of 0.18, with a player bootstrap from 0.04 to 0.29. The spread inside a receiver is 0.28 yards, and the spread between receivers is 0.18 yards. A rank from two or three attempts is mostly noise. The residual is not a second forty: among 2023 receivers with both numbers, the rank correlation is −0.08.

The same geometry was applied to rookie routes, with the half-second window required to finish before the pass and before contact or a catch. A kept cut appears on only 10 percent of 2023 tracked forward passes, 10 percent of 2024, and 11 percent of 2025. A go route often has no break in the 30-to-110-degree band, and a late throw leaves no legal window. A missing NFL trait stays missing.

## How the prediction was judged

Every model sees the route family, man or zone, cushion, down and distance, field position, formation, alignment, and motion. The conventional block adds height, weight, age, the forty, the ten-yard split, the vertical, the broad jump, the three-cone, and the short shuttle. Age uses the Combine tracking date, or March 1 of the draft year if that date is missing. Missing tests stay missing. The three-cone is absent for most of these receivers. On the 2025 class, adding the NGS grades did not beat the plain conventional model: 0.156 yards of error against 0.148.

Each training receiver has the same total weight, split across his routes. The score is the average absolute error in each receiver's mean separation, with route-level error reported beside it. The receiver's NFL exit, targets, and yards are not predictors.

The 2023 class is the development set, with receivers held out of their own predictions. The 2024 class is a chronological check. The recipe is refit on both and applied once to 2025. A useful gain was defined in advance as 0.10 yards off the player-mean error. That bar is an analyst's choice, not a league standard.

## What 2025 showed

Figure 4 is the held-out result: 19 receivers and 3,552 routes. Route context alone missed player-mean separation by 0.187 yards. Conventional tests lowered that to 0.148. The cut-exit residual lowered it to 0.132. The tracking increment is 0.016 yards. A paired bootstrap of those 19 receivers, 2,000 resamples of the frozen predictions, runs from −0.033 to +0.002. The interval includes no gain. The point estimate is about one-sixth of the 0.10 yard bar.

Development had already been unkind. The 2023 out-of-fold test showed the residual increasing error by 0.034 yards. The 2024 check changed error by −0.002 yards, and a bootstrap that refit the training model put that change between −0.018 and +0.011. The holdout number is the friendliest of the three, and it still misses both the interval and the practical bar. A three-frame or seven-frame smooth, instead of the primary five, moves the holdout increment by about a thousandth of a yard. Checking the route bar at 10 and at 40 does not change the conclusion.

The fitted direction contradicts the hypothesis. One standard deviation of the residual, 0.20 yards, is associated with 0.038 yards less predicted separation. Receivers who beat the expected exit were predicted to separate slightly less. Swapping the residual for entry speed alone lands at 0.137 yards of error, within 0.005 of the residual model. Route-level error barely moves, from 1.428 yards to 1.425. Player means look precise because they average hundreds of routes. The tracking term does not tighten the routes themselves.

Figure 3 asks whether the Combine trait reappears on Sundays, separate from the separation model. Among 20 receivers in 2025 with both residuals, the rank correlation is 0.08. The 2024 check, on 21 receivers, was −0.31. The Indianapolis measurement does not reliably show up in rookie routes.

Figure 6 plots the 19 player means against the tracking prediction. The cloud follows the diagonal, with a calibration slope of 0.94, and it still has misses of several tenths of a yard. Figure 5 names three receivers under a rule written first. Among the 16 modeled 2025 receivers whose forty sat within 0.15 seconds of the training median of 4.46, the pair is the largest gap in each direction between a tracking projection and a conventional projection. Those projections average the training route mix. They do not use the prospect's future routes.

Jaylin Noel ran 4.39 and posted a residual of +0.26 yards on three attempts, with a leave-one-attempt spread of 0.13. His tracking projection sat 0.078 yards below the conventional one. Observed mean separation was 3.22. The conventional prediction on the routes he ran was 3.20, and the tracking prediction was 3.14. Conventional was closer. Jaylin Lane ran 4.34 and posted −0.40 yards, also on three attempts. Because the fitted sign treats a poor exit as a plus, his tracking projection sat 0.055 yards above the conventional one. Observed separation was 3.18, nearer the tracking figure of 3.16 than the conventional 3.10. The case that agrees does so for the reason the hypothesis rejected.

Dont'e Thornton is the largest miss, chosen after the outcomes for that reason. Both models put him near 2.9 yards. He averaged 2.54. His residual, +0.10, comes from two attempts with a leave-one-out spread of 0.30 yards. The miss dwarfs the tracking adjustment. A fast forty did not flag it either.

On man-coverage routes the tracking increment is again about 0.016 yards, and both Combine models are worse than route context alone: 0.236 and 0.253 against 0.180. The residual is not a man-coverage specialist grade.

## What to do with it

A scout comparing receivers who have already run a similar forty should keep the conventional tests and leave the cut-exit residual off the ranking. Conventional testing is what moved the error, from 0.187 yards to 0.148. The tracking increment missed the size bar, the bootstrap interval, the sign that was hypothesized, and any stable echo in the NFL routes.

A coach can still put the measurement on a drill sheet. Use breaks in the shared band, about 6 to 8 yards per second into a turn of 30 to 90 degrees, mark the halfway point of the heading change, and record yards along the exit over the next half-second. A swing smaller than about 0.3 yards sits inside the attempt-to-attempt noise of 0.28 yards. These files do not show that improving the drill number will raise separation, and the NFL version exists on only about one route in ten, so it is a weak week-to-week grade. Receivers who never reached 20 clean rookie routes, a 2025 group that is mostly undrafted, are outside the claim.

Nineteen holdout receivers make a wide interval ordinary. Three Combine years are tied to three draft classes, so a year effect and a class effect cannot be separated. The endpoint is separation when a pass is thrown. Screens were dropped before any model was fit. The residual describes the path. It is not a limb test, and it is not a training prescription.
